from sqlalchemy import Column, Integer, String, JSON, Float, Text, ForeignKey
from sqlalchemy.orm import relationship
from .db import Base

class Event(Base):
    __tablename__='events'
    id=Column(Integer, primary_key=True)
    event_id=Column(String, index=True)
    type=Column(String, index=True)
    actor=Column(String)
    payload=Column(JSON)
    timestamp=Column(Float)
    trace_id=Column(String, index=True)

class Bug(Base):
    __tablename__='bugs'
    id=Column(Integer, primary_key=True)
    title=Column(String)
    status=Column(String, index=True, default='Open')
    severity=Column(String, default='P2')
    signature=Column(String, index=True)
    reopen_count=Column(Integer, default=0)

class BugOccurrence(Base):
    __tablename__='bug_occurrences'
    id=Column(Integer, primary_key=True)
    bug_id=Column(Integer, ForeignKey('bugs.id'))
    test_run_id=Column(Integer, index=True, nullable=True)
    evidence=Column(JSON)
    bug=relationship('Bug')

class SprintReview(Base):
    __tablename__='sprint_reviews'
    id=Column(Integer, primary_key=True)
    summary_md=Column(Text)
    metrics=Column(JSON)
    actions=Column(JSON)
