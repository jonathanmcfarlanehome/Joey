from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from .db import Base, engine, SessionLocal
from . import models

app=FastAPI(title='Crowley API')
Base.metadata.create_all(bind=engine)

def get_db():
    db=SessionLocal()
    try:
        yield db
    finally:
        db.close()

class EventIn(BaseModel):
    id:str; type:str; actor:str; payload:dict; timestamp:float; trace_id:str

@app.post('/events')
def create_event(evt:EventIn, db:Session=Depends(get_db)):
    e=models.Event(event_id=evt.id,type=evt.type,actor=evt.actor,payload=evt.payload,timestamp=evt.timestamp,trace_id=evt.trace_id)
    db.add(e); db.commit(); return {'ok':True}

class FailureIn(BaseModel):
    signature:str
    failure:dict

@app.post('/bugs/from_failure')
def bug_from_failure(inp:FailureIn, db:Session=Depends(get_db)):
    bug=db.query(models.Bug).filter(models.Bug.signature==inp.signature).first()
    if bug:
        if (bug.status or '').lower() in ('resolved','closed'):
            bug.status='Reopened'; bug.reopen_count=(bug.reopen_count or 0)+1
        occ=models.BugOccurrence(bug_id=bug.id, evidence=inp.failure)
        db.add(occ); db.commit(); return {'ok':True,'bug_id':bug.id,'reopened':True}
    else:
        title=inp.failure.get('test_name','Test failure')
        bug=models.Bug(title=title,status='Open',severity='P1',signature=inp.signature)
        db.add(bug); db.commit()
        occ=models.BugOccurrence(bug_id=bug.id, evidence=inp.failure)
        db.add(occ); db.commit(); return {'ok':True,'bug_id':bug.id,'created':True}

@app.get('/bugs')
def list_bugs(db:Session=Depends(get_db)):
    rows=db.query(models.Bug).all()
    return [{'id':b.id,'title':b.title,'status':b.status,'reopen_count':b.reopen_count,'signature':b.signature} for b in rows]
