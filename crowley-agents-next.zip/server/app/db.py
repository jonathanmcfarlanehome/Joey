import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
PG_USER=os.getenv("POSTGRES_USER","crowley")
PG_PASS=os.getenv("POSTGRES_PASSWORD","crowley")
PG_DB=os.getenv("POSTGRES_DB","crowley")
PG_HOST=os.getenv("POSTGRES_HOST","postgres")
PG_PORT=os.getenv("POSTGRES_PORT","5432")
DATABASE_URL=f"postgresql+psycopg2://{PG_USER}:{PG_PASS}@{PG_HOST}:{PG_PORT}/{PG_DB}"
engine=create_engine(DATABASE_URL, pool_size=5, max_overflow=10)
SessionLocal=sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base=declarative_base()
