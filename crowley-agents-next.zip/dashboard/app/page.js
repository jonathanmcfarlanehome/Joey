'use client'
import { useEffect, useState } from 'react'
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'
export default function Page(){
  const [bugs,setBugs]=useState([])
  useEffect(()=>{fetch(`${API}/bugs`).then(r=>r.json()).then(setBugs).catch(()=>{})},[])
  return (<main><h1 style={{fontSize:'24px',fontWeight:700}}>Crowley — Project Overview</h1><section><h2>Bugs</h2><ul>{bugs.map(b=>(<li key={b.id}><b>#{b.id}</b> {b.title} — <i>{b.status}</i> (reopened {b.reopen_count||0}×)</li>))}</ul></section></main>) }
