export const metadata = { title: 'Crowley Dashboard' };
export default function RootLayout({ children }) { return (<html><body style={{fontFamily:'ui-sans-serif', padding:'16px'}}>{children}</body></html>); }
