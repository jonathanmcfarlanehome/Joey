import os
from dataclasses import dataclass

@dataclass
class LLMConfig:
    provider: str = os.getenv("LLM_PROVIDER", "openai")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_base_url: str = os.getenv("OPENAI_BASE_URL", "").strip() or "https://api.openai.com/v1"
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5-thinking")
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")

class LLM:
    def __init__(self, cfg: LLMConfig | None = None):
        self.cfg = cfg or LLMConfig()
    def generate(self, role: str, prompt: str) -> str:
        if self.cfg.provider == "mock" or (not self.cfg.openai_api_key and not self.cfg.anthropic_api_key):
            return f"[MOCK {role}] {prompt[:300]}..."
        if self.cfg.provider == "openai":
            return self._openai(prompt, role)
        if self.cfg.provider == "anthropic":
            return self._anthropic(prompt, role)
        return f"[UNKNOWN_PROVIDER {role}] {prompt[:300]}..."
    def _openai(self, prompt: str, role: str) -> str:
        import requests
        url = f"{self.cfg.openai_base_url}/chat/completions"
        headers = {"Authorization": f"Bearer {self.cfg.openai_api_key}", "Content-Type": "application/json"}
        data = {"model": self.cfg.openai_model, "messages": [{"role": "system", "content": f"You are the {role} agent in a disciplined multi-agent SDLC."},{"role": "user", "content": prompt}], "temperature": 0.2}
        resp = requests.post(url, headers=headers, json=data, timeout=60)
        resp.raise_for_status()
        j = resp.json()
        return j["choices"][0]["message"]["content"]
    def _anthropic(self, prompt: str, role: str) -> str:
        import requests
        url = "https://api.anthropic.com/v1/messages"
        headers = {"x-api-key": self.cfg.anthropic_api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
        data = {"model": "claude-3-5-sonnet-20240620", "max_tokens": 2000, "temperature": 0.2, "system": f"You are the {role} agent in a disciplined multi-agent SDLC.", "messages": [{"role":"user","content": prompt}]}
        resp = requests.post(url, headers=headers, json=data, timeout=60)
        resp.raise_for_status()
        j = resp.json()
        return "".join([b.get("text","") for b in j.get("content", [])])

llm = LLM()
