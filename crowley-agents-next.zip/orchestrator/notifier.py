import os, requests
SLACK=os.getenv("SLACK_WEBHOOK_URL","" ).strip()
TEAMS=os.getenv("TEAMS_WEBHOOK_URL","" ).strip()

def _post(url, text):
    try:
        requests.post(url, json={"text": text}, timeout=5)
    except Exception:
        pass

def notify_qatest_created(project, counts):
    text=f"Tests created for {project}: {counts}"
    if SLACK: _post(SLACK, text)
    if TEAMS: _post(TEAMS, text)

def notify_qatest_executed(passed, total, cov_line, cov_branch):
    text=f"Tests executed: {passed}/{total} passed. Coverage L/B {cov_line}%/{cov_branch}%"
    if SLACK: _post(SLACK, text)
    if TEAMS: _post(TEAMS, text)
