from dataclasses import dataclass
from typing import List, Dict, Any
import time, uuid

@dataclass
class Message:
    id: str
    type: str
    actor: str
    payload: Dict[str, Any]
    refs: List[str]
    timestamp: float
    trace_id: str

def new_msg(type_, actor, payload, refs=None, trace_id=None):
    import uuid, time
    return Message(id=str(uuid.uuid4())[:8], type=type_, actor=actor, payload=payload, refs=refs or [], timestamp=time.time(), trace_id=trace_id or str(uuid.uuid4())[:8])
