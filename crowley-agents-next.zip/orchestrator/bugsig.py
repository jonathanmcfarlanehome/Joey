import hashlib, json

def normalize_stacktrace(stack:str)->str:
    lines=[l.strip() for l in (stack or '').splitlines() if l.strip()]
    return "\n".join(lines[:50])

def signature(payload:dict)->str:
    key=json.dumps({"test":payload.get("test_name"),"err":normalize_stacktrace(payload.get("stack","")),"route":payload.get("route"),"error":payload.get("error_type")}, sort_keys=True)
    return hashlib.sha256(key.encode()).hexdigest()[:16]
