import os, json, pathlib, requests
from dotenv import load_dotenv
from .events import new_msg
from .bugsig import signature

load_dotenv()
API_URL=os.getenv("API_URL","http://localhost:8000")
OUT=pathlib.Path(__file__).resolve().parents[1]/"out"
OUT.mkdir(exist_ok=True)

def emit(msg):
    (OUT/f"{msg.timestamp:.0f}_{msg.type}_{msg.id}.json").write_text(json.dumps(msg.__dict__, indent=2))
    try:
        requests.post(f"{API_URL}/events", json=msg.__dict__, timeout=3)
    except Exception:
        pass

def fake_flow():
    prd={"title":"URL Shortener MVP","acceptance":["Given long URL, POST -> short code","Given short code, GET -> redirect","Invalid code -> 404"]}
    emit(new_msg("PRDReady","Intake",{"prd":prd}))
    backlog=[{"id":"WI-1","type":"story","title":"Create short link","points":3,"priority":"P1","status":"Backlog"}]
    emit(new_msg("BacklogReady","Planner",{"items":backlog}))
    emit(new_msg("TestCreated","QA",{"summary":{"project":"url-shortener","counts":{"unit":8,"e2e":3,"a11y":1}}}))
    failure={"test_name":"test_redirect_invalid_code_returns_404","error_type":"AssertionError","stack":"AssertionError: expected 404 got 302"}
    report={"project":"url-shortener","total":12,"passed":11,"failed":1,"cov_line":81,"cov_branch":72,"failures":[failure]}
    emit(new_msg("TestExecuted","CI",{"report":report}))
    for f in report["failures"]:
        sig=signature({"test_name":f["test_name"],"stack":f["stack"],"error_type":f["error_type"]})
        try:
            requests.post(f"{API_URL}/bugs/from_failure", json={"signature":sig,"failure":f}, timeout=5)
        except Exception:
            pass
    review={"kpis":{"closure_rate":0.8,"reopen_rate":0.1,"cov_line":81,"cov_branch":72},"actions":[{"title":"Add property test for invalid code canonicalization"}]}
    emit(new_msg("SprintReviewReady","Release",{"review":review}))

if __name__=="__main__":
    fake_flow()
