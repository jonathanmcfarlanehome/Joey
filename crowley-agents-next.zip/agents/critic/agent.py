from orchestrator.llm import llm

def run(input_payload: dict) -> dict:
    prompt = input_payload.get("prompt", "Produce the artifact.")
    text = llm.generate(role="Critic", prompt=prompt)
    return {"text": text}
