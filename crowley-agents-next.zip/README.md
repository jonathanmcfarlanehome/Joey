# Crowley Agents — Next
See docker-compose.yml. Run: `cp .env.example .env && docker compose up --build`, then `python -m orchestrator.graph`.
